
// chapter 38-41 FUNCTIONS, SWITCH STATEMENTS, WHILE… DO-WHILE LOOPS

// 1. Write a custom function power ( a, b ), to calculate the value of a raised to b.

function custom() {

  var a = +prompt("enter first number");
  var b = +prompt("enter second number");
  var power = Math.pow(a, b);
  alert("a^b is :", power)

}


//2. Any year is entered through the keyboard. Write a function to determine whether the year is a leap year or not. 
//Leap years ..., 2012, 2016, 2020, … Leap years ..., 2012, 2016, 2020, …



function leapyear() {
  var y = document.getElementById("year").value;
  document.getElementById("jazz").innerHTML = (y % 100 == 0) ? (y % 400 == 0) : (y % 4 == 0);


}





// 3. If the lengths of the sides of a triangle are denoted by a, b, and c, then area of triangle is given by
// area = S(S − a)(S − b)(S − c)
// where, S = ( a + b + c ) / 2
// Calculate area of triangle using 2 functions
function angle() {
  var a = +prompt("enter first side of triangle");
  var b = +prompt("enter second side of triangle");
  var c = +prompt("enter third side of triangle");
  var s = a + b + c / 2;
  var area = s * s - a * s - b * s - c;
  alert("The area of triangle is: " + dd)
}



//4. Write a function that receives marks received by a student in 3 subjects and 
//returns the average and percentage of these
//marks. there should be 3 functions one is the mainFunction and other are for average and percentage.
// Call those functions from mainFunction and display result in mainFunction.

function main() {
  var first = + prompt("enter marks of urdu subject ");

  var second = + prompt("enter marks of english subject");

  var third = + prompt("enter marks of math subject");
  document.write("obtained marks of urdu  ", first, "   in english   ", second, "    in math is", third + "<br>");
  avg()
  percent()
  function percent() {
    var perc = first + second + third / 600 * 100;
    document.write("your percentage is", perc + "%<br>");

  }

  function avg() {
    var aver = first + second + third / 3;
    document.write("your average marks  is", aver + "<br>");
  }


}
//5. You have learned the function indexOf.
// Code your own custom function that will perform the same functionality.
// You can code for single character as of now.
function fff() {

  var tell = prompt("enter something in words", "ruqia");
  var check = prompt("which character you want to search from word");

  for (var i = 0; i < tell.length; i++) {

    if (tell.charAt(i) === check) {
      alert("character is found in word choosen");
      break;
    }


  }



}

//  Display an image in browser. 
// Change the picture on mouseover and set the first picture on mouseout.




// 6. Write a function to delete all vowels from a sentence. 
// Assume that the sentence is not more than 25 characters long.

function ccc() {

  var p = ["a", "e", "i", "o", "u"];
  var entrd = prompt("enter a sentence max-length:25");
  if (entrd.length > 25) {
    alert("sentence should not more than 25 characters long")

  }

  var sp = entrd.split("");
  for (j = 0; j < p.length; j++) {
    for (i = 0; i < sp.length; i++) {
      if (sp[i] == p[j]) {

        console.log(" vowels found! ");
        var t = entrd.replace(/[aeiou]/g, "");
        alert(t);
      }

      break;
    }

  }


}





// 7. Write a function with switch statement to count the number of occurrences of any 
// two vowels in succession in a line of text. For example, in the sentence
//“Pleases read this application and give me gratuity”
//Such occurrences are ea, ea, ui.


function voweldouble() {

  p = ["aa", "ae", "ai", "ao", "au", "ea", "ei", "eo", "eu", "ee", "ia", "ie", "ii", "io", "iu", "oa",
    "oe", "oi", "oo", "ou", "ua", "ue", "ui", "uu", "uo"];
  count = 0;
  var entrd = prompt("enter a sentence ", "Pleases read this application and give me gratuity");
  var sp = entrd.split("");
  for (j = 0; j < p.length; j++) {
    for (i = 0; i < sp.length; i++) {
      if (sp[i] + sp[i + 1] == p[j]) {
        count += 1;
      }
    }
  }
  if (count > 0) {
    alert(" double vowels found " + count + " times");

  }
}
// ///////////////////////////








//8. The distance between two cities (in km.) is input through the keyboard.
// Write four functions to convert and print this distance in meters, feet, inches and centimeters.

function aaa() {
  var km = prompt("enter distance between two cities in KM.");
  var m = km / 1000;
  document.write("the distance b/w two cities in meter is : " + m + "<br>");
  var cm = m / 100;
  document.write("the distance b/w two cities in centi-meter is : " + cm + "<br>");
  var inche = cm * 30;
  document.write("the distance b/w two cities in inches is : " + inche + "<br>");
  var feet = inche * 12;
  document.write("the distance b/w two cities in feets is : " + feet + "<br>");


}




//9. Write a program to calculate overtime pay of employees.
// Overtime is paid at the rate of Rs. 12.00 per hour for every hour worked above 40 hours.
//Assume that employees do not work for fractional part of an hour.

function abc() {
  hours = +prompt("enter hours of work in a week!");
  if (hours > 40) {
    var bonus = hours * 12.00;
    document.write("you worked more than 4o hours a week so your overtime pay  is  ", bonus + " Rs");

  }
  else {
    document.write("you  have not worked more than 4o hours , your salery remains unchanged. ");

  }

}


//10. A cashier has currency notes of denominations 10, 50 and 100. 
//If the amount to be withdrawn is input through the keyboard in hundreds,
//find the total number of currency notes of each denomination the cashier will have to give to the withdrawer.

function out(){
    var c1 = prompt("enter amount  to withdraw!!",470);
    var lnth = c1.length;
    var a1 = 10;
    var a2 = 50;
    var a3 = 100;

if (lnth==2) {
 c1[-1]*10;
 c1[-2]*50;
 c1[-3]*100;
 alert("")
 


}
else if (lnth==3){

}
else{

}


}

///////////////////////////////////////////////////////////////////////////////
//----------------------------------EVENTS
/////////////////////////////////////////////////////////////////////////////



//1. Show an alert box on click on a link.
function ppp() {
  alert("Mobile phones of pakistan ");

}


// 2. Display some Mobile images in browser. On click on an image Show the message in alert to user.



// /3. Display 10 student records in table and each row should contain a delete button.
// / If you click on a button to delete a record, entire row should be deleted.
function dl(e) {
  var a = document.getElementById(e);
  a.innerHTML="";
  console.log(a);
}



// 4. Display an image in browser. Change the picture on mouseover and set the first picture on mouseout.


//5. Show a counter in browser. Counter should increase on click on increase button
// and decrease on click on decrease button. And show updated counter value in browser.


// 1. Create a signup form and display form data in your web
// page on submission.



// 2. Suppose in your webpage there is content area in which
// you have entered your item details, but user can only see
// some details on first look. When user clicks on “Read
// more” button, full detail of that particular item will be
// displayed.







// 3. In previous assignment you have created a tabular data
// using javascript. Let’s modify that. Create a form which
// takes student’s details and show each student detail in
// table. Each row of table must contain a delete button and
// an edit button. On click on delete button entire row should
// be deleted. On click on edit button, a hidden form will
// appear with the values of that row.


function poop() {
  var ss = document.getElementById("name1").value;
  var kk = document.getElementById("age").value;
  var jj = document.getElementById("contact").value;

  var fo1 = document.getElementById("foo1");
  var fo2 = document.getElementById("foo2");
  var fo3 = document.getElementById("foo3");

  fo1.innerHTML = ss;
  fo2.innerHTML = kk;
  fo3.innerHTML = jj;

}


/////////////////////////////////////////////////
function xyz(e) {
  var v = document.getElementById("modelimhr");
  v.src = e.src;
  console.log(v.src)

}



















// 5. Show a counter in browser. 
//Counter should increase on click on increase button and
//decrease on click on decrease button.
// And show updated counter value in browser.

function inc() {

  interval = setInterval(CSSStyleDeclaration, 100);
  var interval;
  var a = document.getElementById("btn");
  k++;
  a.innerHTML = k;

}


var k = 0;

function dec() {

  interval = setInterval(CSSStyleDeclaration, 100);
  var interval;
  var a = document.getElementById("btn");
  k--;
  a.innerHTML = k;


}







function signup() {
  var one = document.getElementById("fname");
  var g = one.value;
  var two = document.getElementById("lname");
  var h = two.value;
  var three = document.getElementById("email");
  var k = three.value;


  document.write(g + " " + h + " " + k);
}

function web() {
  text = " Lorem ipsum dolor sit amet consectetur adipisicing elita fuga veritatis inventore corrupti in Magni obcaecati neque provident"
  var ry = document.getElementById("more");
  ry.innerHTML = "";
  var fffy = document.getElementById("gop");
  gop.innerHTML += text;
}
















// ///////////////////////last chapter/////////////////


// i. Get element of id “main-content” and assign them in a variable.
// ii. Display all child elements of “main-content” element.
// iii. Get all elements of class “render” and show their innerHTML in browser.
// iv. Fill input value whose element id first-name using javascript.
// v. Repeat part iv for id ”last-name” and “email”.


var div33 = document.getElementById("”maincontent”");
var p = div33.getElementsByTagName("p");
for (i = 0; i < p.length; i++) {
  var contents = p[i].innerHTML;
  console.log(contents);
}
var p = document.getElementsByClassName("render");
for (i = 0; i < p.length; i++) {
  var contents = p[i].innerHTML;
  console.log(contents);
}
var gog = document.getElementsByClassName("render")
gog[0].innerHTML = "ruqia ";
var toy = document.getElementsByClassName("render");
gog[1].innerHTML = "mughal"
gog[2].innerHTML = "popy@gmail.com"

// 2. use HTML code of question 1 and show the result on browser.

// i. What is node type of element having id “form-content”.
// ii. Show node type of element having id “lastName” and its child node.
// iii. Update child node of element having id “lastName”.
// iv. Get First and last child of id “main-content”.
// v. Get next and previous siblings of id “lastName”.
// vi. Get parent node and node type of element having id “email”



var d = document.getElementById("maincontent");

console.log(d.nodeType);
var e = document.getElementById("lastName");



// var e = document.getElementById("formcontent").childNodes;
// // var r = e.getElementsByTagName("input")
// var t = e[1];
// console.log(t);


// var p = document.getElementById("formcontent");
// var target = p
//  nName = target.nodeName;
//  console.log(nName);
